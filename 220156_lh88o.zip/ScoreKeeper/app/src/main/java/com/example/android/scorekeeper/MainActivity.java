package com.example.android.scorekeeper;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int scoreA = 0;
    int scoreB = 0;
    int gamesA = 0;
    int gamesB = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void displayScoreForTeamA(int score) {
        TextView scoreView = (TextView) findViewById(R.id.player_a_score);
        scoreView.setText(String.valueOf(score));
    }

    public void displayScoreForTeamB(int score) {
        TextView scoreView = (TextView) findViewById(R.id.player_b_score);
        scoreView.setText(String.valueOf(score));
    }

    public void displayGamesForTeamA(int score) {
        TextView scoreView = (TextView) findViewById(R.id.player_a_games);
        scoreView.setText(String.valueOf(score));
    }

    public void displayGamesForTeamB(int score) {
        TextView scoreView = (TextView) findViewById(R.id.player_b_games);
        scoreView.setText(String.valueOf(score));
    }

    public void addPointForA(View view) {
        scoreA = scoreA + 1;
        displayScoreForTeamA(scoreA);
    }

    public void addPointForB(View view) {
        scoreB = scoreB + 1;
        displayScoreForTeamB(scoreB);
    }

    public void addGameForA(View view) {
        gamesA = gamesA + 1;
        displayGamesForTeamA(gamesA);
    }

    public void addGameForB(View view) {
        gamesB = gamesB + 1;
        displayGamesForTeamB(gamesB);
    }

    public void resetPoints(View view) {
        scoreA = 0;
        scoreB = 0;
        displayScoreForTeamA(0);
        displayScoreForTeamB(0);
    }

    public void resetGames(View view) {
        gamesA = 0;
        gamesB = 0;
        displayGamesForTeamA(0);
        displayGamesForTeamB(0);
    }

}
