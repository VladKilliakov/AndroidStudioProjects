package com.example.android.quizapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * The method contains all the logic to define whether a user entered the correct answer.
     * Each correct answer is equal to 1 point. At the end all the points sum up to give
     * the total score.
     *
     * @param view
     */
    public void checkAnswers(View view) {
        RadioGroup question1 = (RadioGroup) findViewById(R.id.q1);
        RadioGroup question2 = (RadioGroup) findViewById(R.id.q2);
        RadioGroup question3 = (RadioGroup) findViewById(R.id.q3);

        int scoreCounter = 0;

        // Getting the index of the user's answer for each radio button
        int q1_answer = question1.indexOfChild(findViewById(question1.getCheckedRadioButtonId()));
        int q2_answer = question2.indexOfChild(findViewById(question2.getCheckedRadioButtonId()));
        int q3_answer = question3.indexOfChild(findViewById(question3.getCheckedRadioButtonId()));

        // Getting the string that the user entered for Question 5
        EditText answerEditText = (EditText) findViewById(R.id.answer5);
        String question5 = answerEditText.getText().toString();

        // Getting CheckBox objects for all checkboxes
        CheckBox question4a1CheckBox = (CheckBox) findViewById(R.id.q4_a1);
        CheckBox question4a2CheckBox = (CheckBox) findViewById(R.id.q4_a2);
        CheckBox question4a3CheckBox = (CheckBox) findViewById(R.id.q4_a3);
        CheckBox question4a4CheckBox = (CheckBox) findViewById(R.id.q4_a4);

        // Conditional tests that check if the questions have the correct answers
        if (q1_answer == 3) {
            scoreCounter += 1;
        }
        if (q2_answer == 3) {
            scoreCounter += 1;
        }
        if (q3_answer == 2) {
            scoreCounter += 1;
        }
        if (question4a1CheckBox.isChecked() && question4a3CheckBox.isChecked()
                && question4a4CheckBox.isChecked() && !(question4a2CheckBox.isChecked())) {
            scoreCounter += 1;
        }
        if (question5.equals(getString(R.string.question5_answer))) {
            scoreCounter += 1;
        }

        showToast(scoreCounter);
    }

    /**
     * The method switches all the radio buttons, checkboxes and a text field to the state with
     * the correct answer.
     *
     * @param view
     */
    public void showAnswers(View view) {
        // Initializing the objects for the radio buttons
        RadioGroup question1 = (RadioGroup) findViewById(R.id.q1);
        RadioGroup question2 = (RadioGroup) findViewById(R.id.q2);
        RadioGroup question3 = (RadioGroup) findViewById(R.id.q3);

        // Initializing the objects for the checkboxes
        CheckBox question4a1CheckBox = (CheckBox) findViewById(R.id.q4_a1);
        CheckBox question4a2CheckBox = (CheckBox) findViewById(R.id.q4_a2);
        CheckBox question4a3CheckBox = (CheckBox) findViewById(R.id.q4_a3);
        CheckBox question4a4CheckBox = (CheckBox) findViewById(R.id.q4_a4);

        // Initializing the object for EditText field
        EditText answer5 = (EditText) findViewById(R.id.answer5);

        question1.check(R.id.q1_a);
        question2.check(R.id.q2_a);
        question3.check(R.id.q3_a);
        question4a1CheckBox.setChecked(true);
        question4a2CheckBox.setChecked(false);
        question4a3CheckBox.setChecked(true);
        question4a4CheckBox.setChecked(true);
        answer5.setText(getString(R.string.question5_answer));
    }

    /**
     * The method displays the toast message with the results of the quiz on the screen
     *
     * @param totalScore is the total number of the correct answers
     */
    public void showToast(int totalScore) {
        Toast toast = Toast.makeText(this, getString(R.string.toast, totalScore), Toast.LENGTH_SHORT);
        toast.show();
    }
}
